﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmCreer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.LblNumContrat = New System.Windows.Forms.Label()
        Me.LblTypeContrat = New System.Windows.Forms.Label()
        Me.LblDateOuverture = New System.Windows.Forms.Label()
        Me.LblLocation = New System.Windows.Forms.Label()
        Me.LblService = New System.Windows.Forms.Label()
        Me.LblDateMiseEnVigueur = New System.Windows.Forms.Label()
        Me.CmbBoxTypeContrat = New System.Windows.Forms.ComboBox()
        Me.LblPaiementMensuel = New System.Windows.Forms.Label()
        Me.TxtBoxPaiement = New System.Windows.Forms.TextBox()
        Me.GBoxOptionContrat = New System.Windows.Forms.GroupBox()
        Me.CBoxAnnee = New System.Windows.Forms.CheckBox()
        Me.CBoxMois = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CmbBoxRaccord = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CmbBoxService = New System.Windows.Forms.ComboBox()
        Me.CmbBoxLocation = New System.Windows.Forms.ComboBox()
        Me.LblAfficheNumContrat = New System.Windows.Forms.Label()
        Me.DTPickerDateMiseEnVigueur = New System.Windows.Forms.DateTimePicker()
        Me.DTPickerDateOuverture = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TxtBoxNomResponsable = New System.Windows.Forms.TextBox()
        Me.TxtBoxRaisonSociale = New System.Windows.Forms.TextBox()
        Me.TxtBoxNas = New System.Windows.Forms.TextBox()
        Me.TxtBoxNumEmploye = New System.Windows.Forms.TextBox()
        Me.TxtBoxTelecopieur = New System.Windows.Forms.TextBox()
        Me.TxtBoxTelphone = New System.Windows.Forms.TextBox()
        Me.TxtBoxAdresse = New System.Windows.Forms.TextBox()
        Me.TxtBoxPrenom = New System.Windows.Forms.TextBox()
        Me.TxtBoxNom = New System.Windows.Forms.TextBox()
        Me.CmbBoxTypeClient = New System.Windows.Forms.ComboBox()
        Me.LblNomResponsable = New System.Windows.Forms.Label()
        Me.LblRaisonSociale = New System.Windows.Forms.Label()
        Me.LblNas = New System.Windows.Forms.Label()
        Me.LblTelecopieur = New System.Windows.Forms.Label()
        Me.LblNumEmploye = New System.Windows.Forms.Label()
        Me.LblTelephone = New System.Windows.Forms.Label()
        Me.LblAdresse = New System.Windows.Forms.Label()
        Me.LblNom = New System.Windows.Forms.Label()
        Me.LblPrenom = New System.Windows.Forms.Label()
        Me.LblNumClient = New System.Windows.Forms.Label()
        Me.LblTypeClient = New System.Windows.Forms.Label()
        Me.BtnQuitter = New System.Windows.Forms.Button()
        Me.BtnCourriel = New System.Windows.Forms.Button()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.BtnImprimer = New System.Windows.Forms.Button()
        Me.BtnCreer = New System.Windows.Forms.Button()
        Me.Titre = New System.Windows.Forms.Label()
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
        Me.LblAfficheNumClient = New System.Windows.Forms.Label()
        Me.GBoxOptionContrat.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.SuspendLayout()
        '
        'LblNumContrat
        '
        Me.LblNumContrat.AutoSize = True
        Me.LblNumContrat.Location = New System.Drawing.Point(401, 32)
        Me.LblNumContrat.Name = "LblNumContrat"
        Me.LblNumContrat.Size = New System.Drawing.Size(96, 13)
        Me.LblNumContrat.TabIndex = 1
        Me.LblNumContrat.Text = "Numéro du Contrat"
        '
        'LblTypeContrat
        '
        Me.LblTypeContrat.AutoSize = True
        Me.LblTypeContrat.Location = New System.Drawing.Point(10, 39)
        Me.LblTypeContrat.Name = "LblTypeContrat"
        Me.LblTypeContrat.Size = New System.Drawing.Size(82, 13)
        Me.LblTypeContrat.TabIndex = 2
        Me.LblTypeContrat.Text = "Type de contrat"
        '
        'LblDateOuverture
        '
        Me.LblDateOuverture.AutoSize = True
        Me.LblDateOuverture.Location = New System.Drawing.Point(6, 78)
        Me.LblDateOuverture.Name = "LblDateOuverture"
        Me.LblDateOuverture.Size = New System.Drawing.Size(86, 13)
        Me.LblDateOuverture.TabIndex = 3
        Me.LblDateOuverture.Text = "Date d'ouverture"
        '
        'LblLocation
        '
        Me.LblLocation.AutoSize = True
        Me.LblLocation.Location = New System.Drawing.Point(401, 78)
        Me.LblLocation.Name = "LblLocation"
        Me.LblLocation.Size = New System.Drawing.Size(106, 13)
        Me.LblLocation.TabIndex = 5
        Me.LblLocation.Text = "Location équipement"
        '
        'LblService
        '
        Me.LblService.AutoSize = True
        Me.LblService.Location = New System.Drawing.Point(401, 112)
        Me.LblService.Name = "LblService"
        Me.LblService.Size = New System.Drawing.Size(43, 13)
        Me.LblService.TabIndex = 6
        Me.LblService.Text = "Service"
        '
        'LblDateMiseEnVigueur
        '
        Me.LblDateMiseEnVigueur.AutoSize = True
        Me.LblDateMiseEnVigueur.Location = New System.Drawing.Point(6, 110)
        Me.LblDateMiseEnVigueur.Name = "LblDateMiseEnVigueur"
        Me.LblDateMiseEnVigueur.Size = New System.Drawing.Size(122, 13)
        Me.LblDateMiseEnVigueur.TabIndex = 7
        Me.LblDateMiseEnVigueur.Text = "Date de mise en vigueur"
        '
        'CmbBoxTypeContrat
        '
        Me.CmbBoxTypeContrat.FormattingEnabled = True
        Me.CmbBoxTypeContrat.Items.AddRange(New Object() {"Actif", "Inactif"})
        Me.CmbBoxTypeContrat.Location = New System.Drawing.Point(130, 31)
        Me.CmbBoxTypeContrat.Name = "CmbBoxTypeContrat"
        Me.CmbBoxTypeContrat.Size = New System.Drawing.Size(121, 21)
        Me.CmbBoxTypeContrat.TabIndex = 15
        '
        'LblPaiementMensuel
        '
        Me.LblPaiementMensuel.AutoSize = True
        Me.LblPaiementMensuel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPaiementMensuel.Location = New System.Drawing.Point(291, 211)
        Me.LblPaiementMensuel.Name = "LblPaiementMensuel"
        Me.LblPaiementMensuel.Size = New System.Drawing.Size(72, 15)
        Me.LblPaiementMensuel.TabIndex = 16
        Me.LblPaiementMensuel.Text = "Paiement "
        '
        'TxtBoxPaiement
        '
        Me.TxtBoxPaiement.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBoxPaiement.Location = New System.Drawing.Point(372, 208)
        Me.TxtBoxPaiement.Name = "TxtBoxPaiement"
        Me.TxtBoxPaiement.Size = New System.Drawing.Size(121, 21)
        Me.TxtBoxPaiement.TabIndex = 17
        Me.TxtBoxPaiement.Text = "0.00 $"
        Me.TxtBoxPaiement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GBoxOptionContrat
        '
        Me.GBoxOptionContrat.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GBoxOptionContrat.Controls.Add(Me.CBoxAnnee)
        Me.GBoxOptionContrat.Controls.Add(Me.CBoxMois)
        Me.GBoxOptionContrat.Controls.Add(Me.Label2)
        Me.GBoxOptionContrat.Controls.Add(Me.CmbBoxRaccord)
        Me.GBoxOptionContrat.Controls.Add(Me.Label1)
        Me.GBoxOptionContrat.Controls.Add(Me.CmbBoxService)
        Me.GBoxOptionContrat.Controls.Add(Me.CmbBoxLocation)
        Me.GBoxOptionContrat.Controls.Add(Me.LblAfficheNumContrat)
        Me.GBoxOptionContrat.Controls.Add(Me.DTPickerDateMiseEnVigueur)
        Me.GBoxOptionContrat.Controls.Add(Me.DTPickerDateOuverture)
        Me.GBoxOptionContrat.Controls.Add(Me.CmbBoxTypeContrat)
        Me.GBoxOptionContrat.Controls.Add(Me.TxtBoxPaiement)
        Me.GBoxOptionContrat.Controls.Add(Me.LblPaiementMensuel)
        Me.GBoxOptionContrat.Controls.Add(Me.LblDateMiseEnVigueur)
        Me.GBoxOptionContrat.Controls.Add(Me.LblDateOuverture)
        Me.GBoxOptionContrat.Controls.Add(Me.LblService)
        Me.GBoxOptionContrat.Controls.Add(Me.LblTypeContrat)
        Me.GBoxOptionContrat.Controls.Add(Me.LblLocation)
        Me.GBoxOptionContrat.Controls.Add(Me.LblNumContrat)
        Me.GBoxOptionContrat.Location = New System.Drawing.Point(160, 278)
        Me.GBoxOptionContrat.Name = "GBoxOptionContrat"
        Me.GBoxOptionContrat.Size = New System.Drawing.Size(834, 242)
        Me.GBoxOptionContrat.TabIndex = 18
        Me.GBoxOptionContrat.TabStop = False
        Me.GBoxOptionContrat.Text = "Options du contrat"
        '
        'CBoxAnnee
        '
        Me.CBoxAnnee.AutoSize = True
        Me.CBoxAnnee.Location = New System.Drawing.Point(438, 183)
        Me.CBoxAnnee.Name = "CBoxAnnee"
        Me.CBoxAnnee.Size = New System.Drawing.Size(59, 17)
        Me.CBoxAnnee.TabIndex = 27
        Me.CBoxAnnee.Text = "Annuel"
        Me.CBoxAnnee.UseVisualStyleBackColor = True
        '
        'CBoxMois
        '
        Me.CBoxMois.AutoSize = True
        Me.CBoxMois.Location = New System.Drawing.Point(371, 183)
        Me.CBoxMois.Name = "CBoxMois"
        Me.CBoxMois.Size = New System.Drawing.Size(66, 17)
        Me.CBoxMois.TabIndex = 26
        Me.CBoxMois.Text = "Mensuel"
        Me.CBoxMois.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(255, 184)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 13)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "Mode de paiement"
        '
        'CmbBoxRaccord
        '
        Me.CmbBoxRaccord.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxRaccord.FormattingEnabled = True
        Me.CmbBoxRaccord.Items.AddRange(New Object() {"$ 0 - Pas de raccordement ", "$ 45 - Raccordement requis"})
        Me.CmbBoxRaccord.Location = New System.Drawing.Point(371, 151)
        Me.CmbBoxRaccord.Name = "CmbBoxRaccord"
        Me.CmbBoxRaccord.Size = New System.Drawing.Size(168, 23)
        Me.CmbBoxRaccord.TabIndex = 24
        Me.CmbBoxRaccord.Text = "Besoin ou pas"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(241, 156)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 13)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Frais de raccordement"
        '
        'CmbBoxService
        '
        Me.CmbBoxService.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxService.FormattingEnabled = True
        Me.CmbBoxService.Items.AddRange(New Object() {"$ 50 - Installation", "$ 20 - Entretien", "$ 60 - Déménagement"})
        Me.CmbBoxService.Location = New System.Drawing.Point(531, 106)
        Me.CmbBoxService.Name = "CmbBoxService"
        Me.CmbBoxService.Size = New System.Drawing.Size(121, 23)
        Me.CmbBoxService.TabIndex = 22
        Me.CmbBoxService.Text = "Choix du service"
        '
        'CmbBoxLocation
        '
        Me.CmbBoxLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmbBoxLocation.FormattingEnabled = True
        Me.CmbBoxLocation.Items.AddRange(New Object() {"$ 6 - Location HP", "$ 5 - Location Cisco"})
        Me.CmbBoxLocation.Location = New System.Drawing.Point(531, 71)
        Me.CmbBoxLocation.Name = "CmbBoxLocation"
        Me.CmbBoxLocation.Size = New System.Drawing.Size(121, 23)
        Me.CmbBoxLocation.TabIndex = 21
        Me.CmbBoxLocation.Text = "Choix de l'équipement"
        '
        'LblAfficheNumContrat
        '
        Me.LblAfficheNumContrat.AutoSize = True
        Me.LblAfficheNumContrat.Location = New System.Drawing.Point(627, 32)
        Me.LblAfficheNumContrat.Name = "LblAfficheNumContrat"
        Me.LblAfficheNumContrat.Size = New System.Drawing.Size(16, 13)
        Me.LblAfficheNumContrat.TabIndex = 20
        Me.LblAfficheNumContrat.Text = "   "
        '
        'DTPickerDateMiseEnVigueur
        '
        Me.DTPickerDateMiseEnVigueur.Location = New System.Drawing.Point(129, 107)
        Me.DTPickerDateMiseEnVigueur.Name = "DTPickerDateMiseEnVigueur"
        Me.DTPickerDateMiseEnVigueur.Size = New System.Drawing.Size(200, 20)
        Me.DTPickerDateMiseEnVigueur.TabIndex = 19
        '
        'DTPickerDateOuverture
        '
        Me.DTPickerDateOuverture.Location = New System.Drawing.Point(129, 72)
        Me.DTPickerDateOuverture.Name = "DTPickerDateOuverture"
        Me.DTPickerDateOuverture.Size = New System.Drawing.Size(200, 20)
        Me.DTPickerDateOuverture.TabIndex = 18
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.TxtBoxNomResponsable)
        Me.GroupBox2.Controls.Add(Me.TxtBoxRaisonSociale)
        Me.GroupBox2.Controls.Add(Me.TxtBoxNas)
        Me.GroupBox2.Controls.Add(Me.TxtBoxNumEmploye)
        Me.GroupBox2.Controls.Add(Me.TxtBoxTelecopieur)
        Me.GroupBox2.Controls.Add(Me.TxtBoxTelphone)
        Me.GroupBox2.Controls.Add(Me.TxtBoxAdresse)
        Me.GroupBox2.Controls.Add(Me.TxtBoxPrenom)
        Me.GroupBox2.Controls.Add(Me.TxtBoxNom)
        Me.GroupBox2.Controls.Add(Me.CmbBoxTypeClient)
        Me.GroupBox2.Controls.Add(Me.LblNomResponsable)
        Me.GroupBox2.Controls.Add(Me.LblRaisonSociale)
        Me.GroupBox2.Controls.Add(Me.LblNas)
        Me.GroupBox2.Controls.Add(Me.LblTelecopieur)
        Me.GroupBox2.Controls.Add(Me.LblNumEmploye)
        Me.GroupBox2.Controls.Add(Me.LblTelephone)
        Me.GroupBox2.Controls.Add(Me.LblAdresse)
        Me.GroupBox2.Controls.Add(Me.LblNom)
        Me.GroupBox2.Controls.Add(Me.LblPrenom)
        Me.GroupBox2.Controls.Add(Me.LblAfficheNumClient)
        Me.GroupBox2.Controls.Add(Me.LblNumClient)
        Me.GroupBox2.Controls.Add(Me.LblTypeClient)
        Me.GroupBox2.Location = New System.Drawing.Point(160, 70)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(834, 185)
        Me.GroupBox2.TabIndex = 19
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Identification du client"
        '
        'TxtBoxNomResponsable
        '
        Me.TxtBoxNomResponsable.Location = New System.Drawing.Point(531, 128)
        Me.TxtBoxNomResponsable.Name = "TxtBoxNomResponsable"
        Me.TxtBoxNomResponsable.Size = New System.Drawing.Size(121, 20)
        Me.TxtBoxNomResponsable.TabIndex = 25
        '
        'TxtBoxRaisonSociale
        '
        Me.TxtBoxRaisonSociale.Location = New System.Drawing.Point(531, 103)
        Me.TxtBoxRaisonSociale.Name = "TxtBoxRaisonSociale"
        Me.TxtBoxRaisonSociale.Size = New System.Drawing.Size(121, 20)
        Me.TxtBoxRaisonSociale.TabIndex = 24
        '
        'TxtBoxNas
        '
        Me.TxtBoxNas.Location = New System.Drawing.Point(531, 76)
        Me.TxtBoxNas.Name = "TxtBoxNas"
        Me.TxtBoxNas.Size = New System.Drawing.Size(121, 20)
        Me.TxtBoxNas.TabIndex = 23
        '
        'TxtBoxNumEmploye
        '
        Me.TxtBoxNumEmploye.Location = New System.Drawing.Point(531, 48)
        Me.TxtBoxNumEmploye.Name = "TxtBoxNumEmploye"
        Me.TxtBoxNumEmploye.Size = New System.Drawing.Size(121, 20)
        Me.TxtBoxNumEmploye.TabIndex = 22
        '
        'TxtBoxTelecopieur
        '
        Me.TxtBoxTelecopieur.Location = New System.Drawing.Point(129, 160)
        Me.TxtBoxTelecopieur.Name = "TxtBoxTelecopieur"
        Me.TxtBoxTelecopieur.Size = New System.Drawing.Size(121, 20)
        Me.TxtBoxTelecopieur.TabIndex = 21
        '
        'TxtBoxTelphone
        '
        Me.TxtBoxTelphone.Location = New System.Drawing.Point(130, 135)
        Me.TxtBoxTelphone.Name = "TxtBoxTelphone"
        Me.TxtBoxTelphone.Size = New System.Drawing.Size(121, 20)
        Me.TxtBoxTelphone.TabIndex = 20
        '
        'TxtBoxAdresse
        '
        Me.TxtBoxAdresse.Location = New System.Drawing.Point(130, 106)
        Me.TxtBoxAdresse.Name = "TxtBoxAdresse"
        Me.TxtBoxAdresse.Size = New System.Drawing.Size(121, 20)
        Me.TxtBoxAdresse.TabIndex = 19
        '
        'TxtBoxPrenom
        '
        Me.TxtBoxPrenom.Location = New System.Drawing.Point(129, 79)
        Me.TxtBoxPrenom.Name = "TxtBoxPrenom"
        Me.TxtBoxPrenom.Size = New System.Drawing.Size(121, 20)
        Me.TxtBoxPrenom.TabIndex = 18
        '
        'TxtBoxNom
        '
        Me.TxtBoxNom.Location = New System.Drawing.Point(130, 52)
        Me.TxtBoxNom.Name = "TxtBoxNom"
        Me.TxtBoxNom.Size = New System.Drawing.Size(121, 20)
        Me.TxtBoxNom.TabIndex = 17
        '
        'CmbBoxTypeClient
        '
        Me.CmbBoxTypeClient.FormattingEnabled = True
        Me.CmbBoxTypeClient.Items.AddRange(New Object() {"Employe", "Particulier", "Entreprise"})
        Me.CmbBoxTypeClient.Location = New System.Drawing.Point(130, 28)
        Me.CmbBoxTypeClient.Name = "CmbBoxTypeClient"
        Me.CmbBoxTypeClient.Size = New System.Drawing.Size(121, 21)
        Me.CmbBoxTypeClient.TabIndex = 16
        '
        'LblNomResponsable
        '
        Me.LblNomResponsable.AutoSize = True
        Me.LblNomResponsable.Location = New System.Drawing.Point(401, 135)
        Me.LblNomResponsable.Name = "LblNomResponsable"
        Me.LblNomResponsable.Size = New System.Drawing.Size(104, 13)
        Me.LblNomResponsable.TabIndex = 14
        Me.LblNomResponsable.Text = "Nom du responsable"
        '
        'LblRaisonSociale
        '
        Me.LblRaisonSociale.AutoSize = True
        Me.LblRaisonSociale.Location = New System.Drawing.Point(401, 109)
        Me.LblRaisonSociale.Name = "LblRaisonSociale"
        Me.LblRaisonSociale.Size = New System.Drawing.Size(76, 13)
        Me.LblRaisonSociale.TabIndex = 13
        Me.LblRaisonSociale.Text = "Raison sociale"
        '
        'LblNas
        '
        Me.LblNas.AutoSize = True
        Me.LblNas.Location = New System.Drawing.Point(401, 79)
        Me.LblNas.Name = "LblNas"
        Me.LblNas.Size = New System.Drawing.Size(29, 13)
        Me.LblNas.TabIndex = 12
        Me.LblNas.Text = "NAS"
        '
        'LblTelecopieur
        '
        Me.LblTelecopieur.AutoSize = True
        Me.LblTelecopieur.Location = New System.Drawing.Point(18, 160)
        Me.LblTelecopieur.Name = "LblTelecopieur"
        Me.LblTelecopieur.Size = New System.Drawing.Size(63, 13)
        Me.LblTelecopieur.TabIndex = 11
        Me.LblTelecopieur.Text = "Télécopieur"
        '
        'LblNumEmploye
        '
        Me.LblNumEmploye.AutoSize = True
        Me.LblNumEmploye.Location = New System.Drawing.Point(401, 55)
        Me.LblNumEmploye.Name = "LblNumEmploye"
        Me.LblNumEmploye.Size = New System.Drawing.Size(86, 13)
        Me.LblNumEmploye.TabIndex = 10
        Me.LblNumEmploye.Text = "Numéro employé"
        '
        'LblTelephone
        '
        Me.LblTelephone.AutoSize = True
        Me.LblTelephone.Location = New System.Drawing.Point(18, 135)
        Me.LblTelephone.Name = "LblTelephone"
        Me.LblTelephone.Size = New System.Drawing.Size(58, 13)
        Me.LblTelephone.TabIndex = 9
        Me.LblTelephone.Text = "Téléphone"
        '
        'LblAdresse
        '
        Me.LblAdresse.AutoSize = True
        Me.LblAdresse.Location = New System.Drawing.Point(18, 106)
        Me.LblAdresse.Name = "LblAdresse"
        Me.LblAdresse.Size = New System.Drawing.Size(45, 13)
        Me.LblAdresse.TabIndex = 8
        Me.LblAdresse.Text = "Adresse"
        '
        'LblNom
        '
        Me.LblNom.AutoSize = True
        Me.LblNom.Location = New System.Drawing.Point(18, 52)
        Me.LblNom.Name = "LblNom"
        Me.LblNom.Size = New System.Drawing.Size(29, 13)
        Me.LblNom.TabIndex = 7
        Me.LblNom.Text = "Nom"
        '
        'LblPrenom
        '
        Me.LblPrenom.AutoSize = True
        Me.LblPrenom.Location = New System.Drawing.Point(18, 79)
        Me.LblPrenom.Name = "LblPrenom"
        Me.LblPrenom.Size = New System.Drawing.Size(43, 13)
        Me.LblPrenom.TabIndex = 6
        Me.LblPrenom.Text = "Prenom"
        '
        'LblNumClient
        '
        Me.LblNumClient.AutoSize = True
        Me.LblNumClient.Location = New System.Drawing.Point(401, 28)
        Me.LblNumClient.Name = "LblNumClient"
        Me.LblNumClient.Size = New System.Drawing.Size(87, 13)
        Me.LblNumClient.TabIndex = 4
        Me.LblNumClient.Text = "Numéro du client"
        '
        'LblTypeClient
        '
        Me.LblTypeClient.AutoSize = True
        Me.LblTypeClient.Location = New System.Drawing.Point(18, 28)
        Me.LblTypeClient.Name = "LblTypeClient"
        Me.LblTypeClient.Size = New System.Drawing.Size(74, 13)
        Me.LblTypeClient.TabIndex = 3
        Me.LblTypeClient.Text = "Type de client"
        '
        'BtnQuitter
        '
        Me.BtnQuitter.BackColor = System.Drawing.SystemColors.ControlLight
        Me.BtnQuitter.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnQuitter.Location = New System.Drawing.Point(22, 370)
        Me.BtnQuitter.Name = "BtnQuitter"
        Me.BtnQuitter.Size = New System.Drawing.Size(91, 54)
        Me.BtnQuitter.TabIndex = 20
        Me.BtnQuitter.Text = "Quitter"
        Me.BtnQuitter.UseVisualStyleBackColor = False
        '
        'BtnCourriel
        '
        Me.BtnCourriel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCourriel.Location = New System.Drawing.Point(22, 144)
        Me.BtnCourriel.Name = "BtnCourriel"
        Me.BtnCourriel.Size = New System.Drawing.Size(91, 49)
        Me.BtnCourriel.TabIndex = 24
        Me.BtnCourriel.Text = "Envoyer par Courriel"
        Me.BtnCourriel.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox8.Controls.Add(Me.BtnCourriel)
        Me.GroupBox8.Controls.Add(Me.BtnQuitter)
        Me.GroupBox8.Controls.Add(Me.BtnImprimer)
        Me.GroupBox8.Controls.Add(Me.BtnCreer)
        Me.GroupBox8.Location = New System.Drawing.Point(12, 70)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(131, 450)
        Me.GroupBox8.TabIndex = 25
        Me.GroupBox8.TabStop = False
        '
        'BtnImprimer
        '
        Me.BtnImprimer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnImprimer.Image = Global.SGARI_Projet.My.Resources.Resources.Printer
        Me.BtnImprimer.Location = New System.Drawing.Point(22, 240)
        Me.BtnImprimer.Name = "BtnImprimer"
        Me.BtnImprimer.Size = New System.Drawing.Size(91, 62)
        Me.BtnImprimer.TabIndex = 22
        Me.BtnImprimer.Text = "Imprimer"
        Me.BtnImprimer.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnImprimer.UseVisualStyleBackColor = True
        '
        'BtnCreer
        '
        Me.BtnCreer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCreer.Image = Global.SGARI_Projet.My.Resources.Resources.if_new_doc_11104
        Me.BtnCreer.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnCreer.Location = New System.Drawing.Point(22, 55)
        Me.BtnCreer.Name = "BtnCreer"
        Me.BtnCreer.Size = New System.Drawing.Size(91, 49)
        Me.BtnCreer.TabIndex = 21
        Me.BtnCreer.Text = "Créer"
        Me.BtnCreer.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnCreer.UseVisualStyleBackColor = True
        '
        'Titre
        '
        Me.Titre.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Titre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Titre.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Titre.Location = New System.Drawing.Point(353, 30)
        Me.Titre.Name = "Titre"
        Me.Titre.Size = New System.Drawing.Size(384, 23)
        Me.Titre.TabIndex = 39
        Me.Titre.Text = "Nouveau contrat"
        Me.Titre.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PrintDialog1
        '
        Me.PrintDialog1.UseEXDialog = True
        '
        'LblAfficheNumClient
        '
        Me.LblAfficheNumClient.AutoSize = True
        Me.LblAfficheNumClient.Location = New System.Drawing.Point(630, 28)
        Me.LblAfficheNumClient.Name = "LblAfficheNumClient"
        Me.LblAfficheNumClient.Size = New System.Drawing.Size(16, 13)
        Me.LblAfficheNumClient.TabIndex = 5
        Me.LblAfficheNumClient.Text = "   "
        '
        'FrmCreer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Menu
        Me.ClientSize = New System.Drawing.Size(1084, 572)
        Me.Controls.Add(Me.Titre)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GBoxOptionContrat)
        Me.Name = "FrmCreer"
        Me.Text = "Nouveau contrat"
        Me.GBoxOptionContrat.ResumeLayout(False)
        Me.GBoxOptionContrat.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents LblNumContrat As Label
    Friend WithEvents LblTypeContrat As Label
    Friend WithEvents LblDateOuverture As Label
    Friend WithEvents LblLocation As Label
    Friend WithEvents LblService As Label
    Friend WithEvents LblDateMiseEnVigueur As Label
    Friend WithEvents CmbBoxTypeContrat As ComboBox
    Friend WithEvents LblPaiementMensuel As Label
    Friend WithEvents TxtBoxPaiement As TextBox
    Friend WithEvents GBoxOptionContrat As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents TxtBoxNomResponsable As TextBox
    Friend WithEvents TxtBoxRaisonSociale As TextBox
    Friend WithEvents TxtBoxNas As TextBox
    Friend WithEvents TxtBoxNumEmploye As TextBox
    Friend WithEvents TxtBoxTelecopieur As TextBox
    Friend WithEvents TxtBoxTelphone As TextBox
    Friend WithEvents TxtBoxAdresse As TextBox
    Friend WithEvents TxtBoxPrenom As TextBox
    Friend WithEvents TxtBoxNom As TextBox
    Friend WithEvents CmbBoxTypeClient As ComboBox
    Friend WithEvents LblNomResponsable As Label
    Friend WithEvents LblRaisonSociale As Label
    Friend WithEvents LblNas As Label
    Friend WithEvents LblTelecopieur As Label
    Friend WithEvents LblNumEmploye As Label
    Friend WithEvents LblTelephone As Label
    Friend WithEvents LblAdresse As Label
    Friend WithEvents LblNom As Label
    Friend WithEvents LblPrenom As Label
    Friend WithEvents LblNumClient As Label
    Friend WithEvents LblTypeClient As Label
    Friend WithEvents DTPickerDateOuverture As DateTimePicker
    Friend WithEvents DTPickerDateMiseEnVigueur As DateTimePicker
    Friend WithEvents BtnQuitter As Button
    Friend WithEvents BtnCreer As Button
    Friend WithEvents BtnImprimer As Button
    Friend WithEvents BtnCourriel As Button
    Friend WithEvents LblAfficheNumContrat As Label
    Friend WithEvents CmbBoxLocation As ComboBox
    Friend WithEvents CmbBoxService As ComboBox
    Friend WithEvents CmbBoxRaccord As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents CBoxAnnee As CheckBox
    Friend WithEvents CBoxMois As CheckBox
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents Titre As Label
    Friend WithEvents PrintDialog1 As PrintDialog
    Friend WithEvents LblAfficheNumClient As Label
End Class
