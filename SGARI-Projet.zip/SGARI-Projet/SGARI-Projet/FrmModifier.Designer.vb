﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmModifier
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.BtnRechercher = New System.Windows.Forms.Button()
        Me.BtnMQuitter = New System.Windows.Forms.Button()
        Me.BtnMNSearch = New System.Windows.Forms.Button()
        Me.BtnModifier = New System.Windows.Forms.Button()
        Me.LblMDMService = New System.Windows.Forms.Label()
        Me.LblMService = New System.Windows.Forms.Label()
        Me.LblMLocation = New System.Windows.Forms.Label()
        Me.LblMDF = New System.Windows.Forms.Label()
        Me.LblMDO = New System.Windows.Forms.Label()
        Me.LblMTCnt = New System.Windows.Forms.Label()
        Me.LblMNumCnt = New System.Windows.Forms.Label()
        Me.TxtBoxNumCnt = New System.Windows.Forms.TextBox()
        Me.LblNumContratAModifier = New System.Windows.Forms.Label()
        Me.TBoxMTCnt = New System.Windows.Forms.TextBox()
        Me.TBoxMDO = New System.Windows.Forms.TextBox()
        Me.TBoxMDF = New System.Windows.Forms.TextBox()
        Me.TBoxMLocation = New System.Windows.Forms.TextBox()
        Me.TBoxMService = New System.Windows.Forms.TextBox()
        Me.TBoxMDMV = New System.Windows.Forms.TextBox()
        Me.LblMNC = New System.Windows.Forms.Label()
        Me.GBoxRecherche = New System.Windows.Forms.GroupBox()
        Me.LblMessage = New System.Windows.Forms.Label()
        Me.LblMessageMaj = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.GBoxRecherche.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BtnRechercher
        '
        Me.BtnRechercher.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRechercher.Location = New System.Drawing.Point(553, 47)
        Me.BtnRechercher.Name = "BtnRechercher"
        Me.BtnRechercher.Size = New System.Drawing.Size(117, 23)
        Me.BtnRechercher.TabIndex = 34
        Me.BtnRechercher.Text = "Rechercher"
        Me.BtnRechercher.UseVisualStyleBackColor = True
        '
        'BtnMQuitter
        '
        Me.BtnMQuitter.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnMQuitter.Location = New System.Drawing.Point(21, 425)
        Me.BtnMQuitter.Name = "BtnMQuitter"
        Me.BtnMQuitter.Size = New System.Drawing.Size(81, 43)
        Me.BtnMQuitter.TabIndex = 33
        Me.BtnMQuitter.Text = "Quitter"
        Me.BtnMQuitter.UseVisualStyleBackColor = True
        '
        'BtnMNSearch
        '
        Me.BtnMNSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnMNSearch.Location = New System.Drawing.Point(21, 279)
        Me.BtnMNSearch.Name = "BtnMNSearch"
        Me.BtnMNSearch.Size = New System.Drawing.Size(81, 50)
        Me.BtnMNSearch.TabIndex = 32
        Me.BtnMNSearch.Text = "Nouvelle Recherche"
        Me.BtnMNSearch.UseVisualStyleBackColor = True
        '
        'BtnModifier
        '
        Me.BtnModifier.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnModifier.Image = Global.SGARI_Projet.My.Resources.Resources.if_update_64935
        Me.BtnModifier.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnModifier.Location = New System.Drawing.Point(18, 196)
        Me.BtnModifier.Name = "BtnModifier"
        Me.BtnModifier.Size = New System.Drawing.Size(81, 54)
        Me.BtnModifier.TabIndex = 31
        Me.BtnModifier.Text = "Modifier"
        Me.BtnModifier.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnModifier.UseVisualStyleBackColor = True
        '
        'LblMDMService
        '
        Me.LblMDMService.AutoSize = True
        Me.LblMDMService.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMDMService.Location = New System.Drawing.Point(350, 203)
        Me.LblMDMService.Name = "LblMDMService"
        Me.LblMDMService.Size = New System.Drawing.Size(174, 18)
        Me.LblMDMService.TabIndex = 29
        Me.LblMDMService.Text = "Date de mise en vigueur :"
        '
        'LblMService
        '
        Me.LblMService.AutoSize = True
        Me.LblMService.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMService.Location = New System.Drawing.Point(350, 156)
        Me.LblMService.Name = "LblMService"
        Me.LblMService.Size = New System.Drawing.Size(65, 18)
        Me.LblMService.TabIndex = 28
        Me.LblMService.Text = "Service :"
        '
        'LblMLocation
        '
        Me.LblMLocation.AutoSize = True
        Me.LblMLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMLocation.Location = New System.Drawing.Point(350, 102)
        Me.LblMLocation.Name = "LblMLocation"
        Me.LblMLocation.Size = New System.Drawing.Size(153, 18)
        Me.LblMLocation.TabIndex = 27
        Me.LblMLocation.Text = "Location équipement :"
        '
        'LblMDF
        '
        Me.LblMDF.AutoSize = True
        Me.LblMDF.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMDF.Location = New System.Drawing.Point(7, 200)
        Me.LblMDF.Name = "LblMDF"
        Me.LblMDF.Size = New System.Drawing.Size(134, 18)
        Me.LblMDF.TabIndex = 26
        Me.LblMDF.Text = "Date de fermeture :"
        '
        'LblMDO
        '
        Me.LblMDO.AutoSize = True
        Me.LblMDO.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMDO.Location = New System.Drawing.Point(7, 147)
        Me.LblMDO.Name = "LblMDO"
        Me.LblMDO.Size = New System.Drawing.Size(124, 18)
        Me.LblMDO.TabIndex = 25
        Me.LblMDO.Text = "Date d'ouverture :"
        '
        'LblMTCnt
        '
        Me.LblMTCnt.AutoSize = True
        Me.LblMTCnt.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMTCnt.Location = New System.Drawing.Point(6, 102)
        Me.LblMTCnt.Name = "LblMTCnt"
        Me.LblMTCnt.Size = New System.Drawing.Size(118, 18)
        Me.LblMTCnt.TabIndex = 24
        Me.LblMTCnt.Text = "Type de contrat :"
        '
        'LblMNumCnt
        '
        Me.LblMNumCnt.AutoSize = True
        Me.LblMNumCnt.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMNumCnt.Location = New System.Drawing.Point(248, 49)
        Me.LblMNumCnt.Name = "LblMNumCnt"
        Me.LblMNumCnt.Size = New System.Drawing.Size(135, 18)
        Me.LblMNumCnt.TabIndex = 23
        Me.LblMNumCnt.Text = "Numéro du Contrat"
        '
        'TxtBoxNumCnt
        '
        Me.TxtBoxNumCnt.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBoxNumCnt.Location = New System.Drawing.Point(251, 49)
        Me.TxtBoxNumCnt.Name = "TxtBoxNumCnt"
        Me.TxtBoxNumCnt.Size = New System.Drawing.Size(246, 24)
        Me.TxtBoxNumCnt.TabIndex = 22
        '
        'LblNumContratAModifier
        '
        Me.LblNumContratAModifier.AutoSize = True
        Me.LblNumContratAModifier.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblNumContratAModifier.Location = New System.Drawing.Point(32, 52)
        Me.LblNumContratAModifier.Name = "LblNumContratAModifier"
        Me.LblNumContratAModifier.Size = New System.Drawing.Size(213, 18)
        Me.LblNumContratAModifier.TabIndex = 21
        Me.LblNumContratAModifier.Text = "Numéro du contrat à modifier : "
        '
        'TBoxMTCnt
        '
        Me.TBoxMTCnt.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBoxMTCnt.Location = New System.Drawing.Point(160, 99)
        Me.TBoxMTCnt.Name = "TBoxMTCnt"
        Me.TBoxMTCnt.Size = New System.Drawing.Size(166, 24)
        Me.TBoxMTCnt.TabIndex = 36
        '
        'TBoxMDO
        '
        Me.TBoxMDO.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBoxMDO.Location = New System.Drawing.Point(160, 147)
        Me.TBoxMDO.Name = "TBoxMDO"
        Me.TBoxMDO.Size = New System.Drawing.Size(166, 24)
        Me.TBoxMDO.TabIndex = 37
        '
        'TBoxMDF
        '
        Me.TBoxMDF.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBoxMDF.Location = New System.Drawing.Point(160, 194)
        Me.TBoxMDF.Name = "TBoxMDF"
        Me.TBoxMDF.Size = New System.Drawing.Size(166, 24)
        Me.TBoxMDF.TabIndex = 38
        '
        'TBoxMLocation
        '
        Me.TBoxMLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBoxMLocation.Location = New System.Drawing.Point(525, 105)
        Me.TBoxMLocation.Name = "TBoxMLocation"
        Me.TBoxMLocation.Size = New System.Drawing.Size(149, 24)
        Me.TBoxMLocation.TabIndex = 39
        '
        'TBoxMService
        '
        Me.TBoxMService.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBoxMService.Location = New System.Drawing.Point(525, 148)
        Me.TBoxMService.Name = "TBoxMService"
        Me.TBoxMService.Size = New System.Drawing.Size(149, 24)
        Me.TBoxMService.TabIndex = 40
        '
        'TBoxMDMV
        '
        Me.TBoxMDMV.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBoxMDMV.Location = New System.Drawing.Point(525, 200)
        Me.TBoxMDMV.Name = "TBoxMDMV"
        Me.TBoxMDMV.Size = New System.Drawing.Size(149, 24)
        Me.TBoxMDMV.TabIndex = 41
        '
        'LblMNC
        '
        Me.LblMNC.BackColor = System.Drawing.Color.White
        Me.LblMNC.Enabled = False
        Me.LblMNC.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMNC.Location = New System.Drawing.Point(398, 41)
        Me.LblMNC.Name = "LblMNC"
        Me.LblMNC.Size = New System.Drawing.Size(126, 26)
        Me.LblMNC.TabIndex = 42
        '
        'GBoxRecherche
        '
        Me.GBoxRecherche.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GBoxRecherche.Controls.Add(Me.LblNumContratAModifier)
        Me.GBoxRecherche.Controls.Add(Me.LblMessage)
        Me.GBoxRecherche.Controls.Add(Me.TxtBoxNumCnt)
        Me.GBoxRecherche.Controls.Add(Me.BtnRechercher)
        Me.GBoxRecherche.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GBoxRecherche.Location = New System.Drawing.Point(12, 21)
        Me.GBoxRecherche.Name = "GBoxRecherche"
        Me.GBoxRecherche.Size = New System.Drawing.Size(785, 132)
        Me.GBoxRecherche.TabIndex = 43
        Me.GBoxRecherche.TabStop = False
        Me.GBoxRecherche.Text = "Recherche du contrat"
        '
        'LblMessage
        '
        Me.LblMessage.AutoSize = True
        Me.LblMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMessage.Location = New System.Drawing.Point(303, 101)
        Me.LblMessage.Name = "LblMessage"
        Me.LblMessage.Size = New System.Drawing.Size(50, 13)
        Me.LblMessage.TabIndex = 44
        Me.LblMessage.Text = "Message"
        '
        'LblMessageMaj
        '
        Me.LblMessageMaj.AutoSize = True
        Me.LblMessageMaj.Location = New System.Drawing.Point(286, 267)
        Me.LblMessageMaj.Name = "LblMessageMaj"
        Me.LblMessageMaj.Size = New System.Drawing.Size(69, 18)
        Me.LblMessageMaj.TabIndex = 45
        Me.LblMessageMaj.Text = "Message"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.LblMessageMaj)
        Me.GroupBox1.Controls.Add(Me.TBoxMService)
        Me.GroupBox1.Controls.Add(Me.LblMNC)
        Me.GroupBox1.Controls.Add(Me.TBoxMLocation)
        Me.GroupBox1.Controls.Add(Me.LblMDMService)
        Me.GroupBox1.Controls.Add(Me.TBoxMDMV)
        Me.GroupBox1.Controls.Add(Me.TBoxMDF)
        Me.GroupBox1.Controls.Add(Me.LblMTCnt)
        Me.GroupBox1.Controls.Add(Me.LblMService)
        Me.GroupBox1.Controls.Add(Me.TBoxMDO)
        Me.GroupBox1.Controls.Add(Me.TBoxMTCnt)
        Me.GroupBox1.Controls.Add(Me.LblMNumCnt)
        Me.GroupBox1.Controls.Add(Me.LblMLocation)
        Me.GroupBox1.Controls.Add(Me.LblMDO)
        Me.GroupBox1.Controls.Add(Me.LblMDF)
        Me.GroupBox1.Enabled = False
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.GroupBox1.Location = New System.Drawing.Point(122, 183)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(686, 299)
        Me.GroupBox1.TabIndex = 46
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Résultat de la recherche et Mise à jour"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox2.Location = New System.Drawing.Point(12, 183)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(104, 299)
        Me.PictureBox2.TabIndex = 47
        Me.PictureBox2.TabStop = False
        '
        'FrmModifier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(809, 526)
        Me.Controls.Add(Me.GBoxRecherche)
        Me.Controls.Add(Me.BtnMQuitter)
        Me.Controls.Add(Me.BtnMNSearch)
        Me.Controls.Add(Me.BtnModifier)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Name = "FrmModifier"
        Me.Text = "Modifier contrat"
        Me.GBoxRecherche.ResumeLayout(False)
        Me.GBoxRecherche.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BtnRechercher As Button
    Friend WithEvents BtnMQuitter As Button
    Friend WithEvents BtnMNSearch As Button
    Friend WithEvents BtnModifier As Button
    Friend WithEvents LblMDMService As Label
    Friend WithEvents LblMService As Label
    Friend WithEvents LblMLocation As Label
    Friend WithEvents LblMDF As Label
    Friend WithEvents LblMDO As Label
    Friend WithEvents LblMTCnt As Label
    Friend WithEvents LblMNumCnt As Label
    Friend WithEvents TxtBoxNumCnt As TextBox
    Friend WithEvents LblNumContratAModifier As Label
    Friend WithEvents TBoxMTCnt As TextBox
    Friend WithEvents TBoxMDO As TextBox
    Friend WithEvents TBoxMDF As TextBox
    Friend WithEvents TBoxMLocation As TextBox
    Friend WithEvents TBoxMService As TextBox
    Friend WithEvents TBoxMDMV As TextBox
    Friend WithEvents LblMNC As Label
    Friend WithEvents GBoxRecherche As GroupBox
    Friend WithEvents LblMessage As Label
    Friend WithEvents LblMessageMaj As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents PictureBox2 As PictureBox
End Class
