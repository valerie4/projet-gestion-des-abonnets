﻿Public Class Sommaire
    Private Sub Sommaire_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Sommaire()

    End Sub
    Sub Sommaire()
        ' Process.Start("C:\Users\sanbo\Desktop\sagari.pdf")
        ListSommaire.Items.Add("                                                         SOMMAIRE ")
        ListSommaire.Items.Add("")
        ListSommaire.Items.Add("   ABONNET est spécialisée dans la gestion des abonnements des clients civils et commerciaux au sein")
        ListSommaire.Items.Add("")
        ListSommaire.Items.Add("    de l'établissement.Pour mettre en confiance notre clientèle et d’éviter la compétitivité ")
        ListSommaire.Items.Add("")
        ListSommaire.Items.Add("    on a mis au point un système de gestion des abonnés d’internet appelée SGARI ")
        ListSommaire.Items.Add("")
        ListSommaire.Items.Add("    ce système a pour but de permettre au client de souscrire à un contrat de location d’équipement ou de resilier au contrat")
        ListSommaire.Items.Add("")
        ListSommaire.Items.Add("    la validation du code d’accès des clients afin d’assurer la sécurité de leur donnée, ")
        ListSommaire.Items.Add("")
        ListSommaire.Items.Add("    gérer la livraison des équipements au client l’amélioration de la gestion des équipements pour éviter la rupture. SAGARI a pour avantage d’avoir un accès ")
        ListSommaire.Items.Add("")
        ListSommaire.Items.Add("    immédiat de l’information fiable et répondre vite à la clientèle, d’améliorer la productivité du personnel et permettre au client de suivre l’évolution de son contrat ")

    End Sub
End Class