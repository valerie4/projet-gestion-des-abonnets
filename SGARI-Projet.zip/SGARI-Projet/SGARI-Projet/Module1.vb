﻿Module Module1
    Public varancmotdepasse As String
    Public varUtilisateur As String
    Public TaxeTPS As Integer
    Public TaxeTVQ As Integer
End Module
